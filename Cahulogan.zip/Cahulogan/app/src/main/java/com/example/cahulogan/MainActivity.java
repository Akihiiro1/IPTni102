package com.example.cahulogan;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cahulogan.viewmodel.FoodViewModel;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Needs R

        RecyclerView recyclerView = findViewById(R.id.recyclerViewItems); // Needs R
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FoodViewModel foodViewModel = new ViewModelProvider(this).get(FoodViewModel.class);
        foodViewModel.getFoods().observe(this, foodList -> {
            FoodAdapter adapter = new FoodAdapter(foodList);
            recyclerView.setAdapter(adapter);
        });
        foodViewModel.loadFoods();
    }
}
